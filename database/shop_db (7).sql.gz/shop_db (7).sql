-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 04:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `number` int(30) NOT NULL,
  `postal_code` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`name`, `address`, `number`, `postal_code`) VALUES
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('james', 'pob', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('jame macart', 'narciso', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('AKO', 'IKAW', 2147483647, 8400),
('one', 'two', 2147483647, 8400),
('AKO', 'waw', 925231342, 8400);

-- --------------------------------------------------------

--
-- Table structure for table `add products`
--

CREATE TABLE `add products` (
  `item` varchar(255) NOT NULL,
  `price` int(30) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `descriptions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add products`
--

INSERT INTO `add products` (`item`, `price`, `image_path`, `descriptions`) VALUES
('nanyang', 800, 'OIP (2).jpg', ''),
('pk5', 2500, 'Sf542ca714eea442c96e1fe6deb3f6f297.jpg_720x720q80.jpg', ''),
('ladder', 800, 'OIP (7).jpg', ''),
('ball', 600, 'OIP (5).jpg', ''),
('net', 500, 'gto-takraw-nets-GT20_2w_2018-10-11_15-26.jpg', ''),
('knee pads', 350, '82340de6-9cdd-4e74-855f-245657e036fb_1.8e2cffb077b31147e732adc09dcb4575.jpeg', ''),
('Water Bottle', 250, 'OIP (9).jpg', ''),
('towel', 150, 'OIP (10).jpg', ''),
('First Aid Kit', 500, 'R.jpg', ''),
('bag', 350, 'original_personalised-golf-shoe-bag.jpg', ''),
('pads', 400, 'OIP (8).jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('socks', 23242, '5246346', ''),
('socks', 23242, '5246346', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', ''),
('marathon ball', 600, 'Ra.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item` varchar(255) NOT NULL,
  `price` int(30) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `descriptions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item`, `price`, `image_path`, `descriptions`) VALUES
('socks', 300, 'OIP (6).jpg', 'e search sa google haha');

-- --------------------------------------------------------

--
-- Table structure for table `log in`
--

CREATE TABLE `log in` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log in`
--

INSERT INTO `log in` (`email`, `password`) VALUES
('AKO', 'AKO'),
('SIJA', 'SIJA'),
('aw', 'aw'),
('ew', 'ew'),
('ah', 'ah');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `item` varchar(255) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `item` varchar(255) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
